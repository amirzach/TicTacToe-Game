package com.example.group_project_csc557;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private EditText nicknameEditText;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button registerButton;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        dbHelper = new DBHelper(this);

        nicknameEditText = findViewById(R.id.signup_nickname);
        usernameEditText = findViewById(R.id.signup_username);
        passwordEditText = findViewById(R.id.signup_password);
        registerButton = findViewById(R.id.signup_button);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nickname = nicknameEditText.getText().toString();
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (dbHelper.isUsernameTaken(username)) {
                    // Username is already taken, show a toast message
                    Toast.makeText(SignupActivity.this, "Username already exists. Please choose another one.", Toast.LENGTH_SHORT).show();
                } else {
                    if (dbHelper.addUser(nickname, username, password)) {
                        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(SignupActivity.this, "Registration failed. Try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
